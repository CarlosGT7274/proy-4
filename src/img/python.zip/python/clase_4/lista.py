'Listas.py'
Lenguajes = [ "Java", "C++", "Python", 'C', 'Cobol', 'Php' ]
# Listas
print(" Trabajando con listas ")
print("+.-.+*|"*10)
print(" Mostrando todos los datos ")
print(Lenguajes)
print(" Mostrando un solo elemento de la lista:-> ", Lenguajes[2])
print("\n Modificando Valores ")
Lenguajes[5] = 'Visual Basic'
print(Lenguajes)
print("\n Agregando Valores ")
print("\n Utilizando Append ")
'Se agregará un valor al final de la lista'
Lenguajes.append("Ruby")
print(Lenguajes)
print("\n Utilizando Insert ")
Lenguajes.insert(0,"JavaScript")
print(Lenguajes)
print("\n Eliminado Elementos de una Lista ")
print(" utilizando del ")
del Lenguajes[0]
print(Lenguajes)
'''del Lenguajes[10]
print(Lenguajes)'''
print(" utilizando 'remove' ")
Lenguajes.remove("Java")
print(Lenguajes)
#Marcará error lógico. Finalizando el programa.
'''Lenguajes.remove("HTML")
print(Lenguajes)'''
print(" \n Eliminando todos los elementos de la lista ")
del Lenguajes[:]
print(Lenguajes)
print(" \n Eliminando todos los elementos de la lista ")
del Lenguajes
print(Lenguajes)