Mensaje = '''Realizando operaciones con numeros complejos'''
print(Mensaje)

a = 10 + 4j
b = complex('8-2j')
c = b
d = complex("2+20j")

print("+."*30)
print("suma de numeros complejos")
print(f"{a} + {c} = {str(a+c)}")

print("+."*30)
print("\n multiplicacion x Escalar")
escalar = int(input("ingresa el numero: "))
resultador = escalar * a
print(f"{escalar} X {a} = {escalar*a}")

print("+."*30)
print("resta de numeros complejos")
print(f"{c} - {b} = {c-b}")

print("+."*30)
print("igualdad de numeros complejos")
print(f"{c} + {b} = {str(c==b)}")

