public class test
{
    public static void main(String args[])
    {
        for(int i = 0; i <= 12; i++)
        {
            System.out.print("12 * "+ i + " = " + 12 * i + "\n");
        }
    }
}
