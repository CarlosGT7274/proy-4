# Tarifas
tarifas = {
    1: 5,
    2: 10,
    3: 20,
    4: 40,
    5: 50,
    6: 120,
    7: 220,
    8: 258
}


# Menú
print("Medios de transporte y tarifas:")
print("1. Persona: $5")
print("2. Bicicleta: $10")
print("3. Motocicleta: $20")
print("4. Automóvil: $40")
print("5. Camioneta: $50")
print("6. Autobús: $120")
print("7. Tráiler: $220")
print("8. Torton: $258")

medios_cruzados = 0
total = 0

while True:
    #Solicitar medio de transporte
    medio = int(input("Seleccione el medio de transporte (1-8): "))
    tarifa = tarifas.get(medio)
    
    if tarifa:
        # Mostrar tarifa correspondiente
        print(f"Medio seleccionado: {medio}")
        print(f"Tarifa correspondiente: ${tarifa}")
        
        # Solicitar depósito
        deposito = int(input("Ingrese el depósito: $"))
        
        if deposito > 0:
             # Verificar si el depósito es suficiente
             if deposito >= tarifa:
                 cambio = deposito - tarifa
                 print(f"Gracias por su depósito, su cambio es de ${cambio}. Buen viaje.")
                 # Actualizar contadores
                 medios_cruzados += 1
                 total += tarifa
                 continuar = input("¿Desea continuar? (S/N): ")
                 if continuar.upper() != "S":
                    break
        
             else: 
                 diferencia = tarifa - deposito
                 print(f"Le falta ${diferencia}. No puede pasar.")
        else:
            print("Depósito inválido.")
            
    else:
        print("Medio de transporte no válido.")
        
        continuar = input("¿Desea continuar? (S/N): ")
        if continuar.upper() != "S":
            break
        

print("Cantidad de medios que cruzaron:", medios_cruzados)
print("Total obtenido: $", total)
                 
        
            
        
