class perros(object):
    def __init__(self, nombre, peso):
        self.__nombre = nombre
        self.__peso = peso        
    @property
    def nombre(self):
        "documentacion del metodo nombre"
        return self.__nombre
    
    
    @nombre.setter
    def nombre(self, nuevo):
        print("modificando nombre..")
        self.__nombre = nuevo
        print("el nombre e ha modificado por :")
        print(self.__nombre)
        
    @nombre.deleter
    def nombre(self):
        print("Borrando nombre..")
        del self.__nombre
        
    @property
    def peso(self):
        return self.__peso

miperro = perros('titan', 15)
print('El Nombre de mi perro: ',miperro.nombre)

miperro.nombre = 'super titan'
del miperro.nombre