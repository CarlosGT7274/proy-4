class Animal:
    def __init__(self, especie, edad):
        self.especie = especie
        self.edad = edad
    def hablar(self):
        pass
    def moverse(self):
        pass
    def decribeme(self):
        print( f"soy un animal del tipo {type(self).__name__}")

class Perro(Animal):
    def hablar(self):
        print("Guau Guau...")
    def moverse(self):
        print("Caminando con cuatro patas")
class Vaca(Animal):
    def hablar(self):
        print("Muu muuu...")
    def moverse(self):
        print("Caminando con cuatro patas")

class Abeja(Animal):
    def hablar(self):
        print("Bzzzz Bzzz..")
    def moverse(self):
        print("Volando")
    def Picar(self):
        print(" Picar ")
#Principal.........................
Roky = Perro("Mamifero",1)
Fee = Vaca("Mamifero",3)
Bee = Abeja("Insecto",10)
#------- Presentacion --------
Roky.decribeme()
Roky.hablar()
Fee.decribeme()
Fee.hablar()
Bee.decribeme()
Bee.hablar()
Bee.Picar()