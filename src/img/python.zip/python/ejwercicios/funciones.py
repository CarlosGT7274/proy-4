Medios = '''Persona, Bicicleta, Motocicleta, Automóvil, Camioneta, Autobús, Tráiler, Torton'''.split(",")
Tarifas = '''5, 10, 20, 40, 50, 120, 220, 258'''.split(",")

import os

def menu ():
    Contador = 1
    print(" Nuestro Menu ")
    print(" ------------ ")
    
    for Medio in Medios: #Mostrando todos los elementos de la lista
        print(f" {Contador}. {Medio} ${Tarifas [Contador-1]}")
        Contador += 1
    print(" 9. Salir ")
    print("\n------------------------------")

    Opcion = int(input(" Ingrese la opcion: "))
    return Opcion

def Cobro (Medio, Tarifa):
    Tarifa = float (Tarifa) #Realizando conversion de cadena a flotante
    print(" Procesando Seleccion... ")
    print("-"*30)
    print (f" Medio: {Medio} \n Tarifa: ${Tarifa}")
    
    pago = float(input("Ingresa tú depósito:->$"))
    while True:
        #os.system("cls")
        if pago > 0:
            if pago > Tarifa:
                cambio = pago - Tarifa
                print("Calculando cambio...")
                print(f"Su cambio es: ${cambio}")
                print("Buen viaje")
                print("-"*30)
                #break
            elif pago == Tarifa:
                print("Cobrando...")
                print("Gracias, su pago fué aceptado")
                print("Buen viaje")
                print("-"*30)
                #break
            else:
                diferencia = Tarifa - pago
                print("Pago insufuciente")
                print(f"\n Le faltan: ${diferencia}")
                print("Vuelva cuando tenga el pago completo, gracias")
                #break
            break
        else:
            print("Pago inválido")
menu()