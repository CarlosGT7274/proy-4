carrito = []
total_articulos = 0
total_pagar = 0

while True:
    producto = input("Ingresa el nombre del producto: ")
    precio = float(input("Ingresa el precio del producto: "))
    carrito.append((producto, precio))
    total_articulos += 1
    total_pagar += precio

    seguir_comprando = input("¿Deseas seguir comprando? (y/n) ")
    if seguir_comprando.lower() == "n":
        break

print("El total de artículos llevados es: ", total_articulos)
print("El total a pagar es: $", total_pagar)