def potencia(base, exponente):
    resultado = 1
    for i in range(exponente):
        resultado = resultado * base
    return resultado


base = 2
exponente = 10
resultado = potencia(base, exponente)
print(resultado)