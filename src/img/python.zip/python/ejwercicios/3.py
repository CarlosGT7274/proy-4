personas = []
suma_imc = 0

for i in range(10):
    peso = float(input(f"Ingresa el peso en kg de la persona {i+1}: "))
    altura = float(input(f"Ingresa la altura en metros de la persona {i+1}: "))
    imc = peso / (altura**2)
    personas.append((peso, altura, imc))
    suma_imc += imc
    print(f"El IMC de la persona {i+1} es: {imc}")

promedio_imc = suma_imc/10
print(f"El IMC promedio es: {promedio_imc}")