class Animal:
    def _init_(self, especie, edad):
        self.especie = especie
        self.edad = edad
    def hablar(self):
        pass
    def moverse(self):
        pass
    def decribeme(self):
        print( f"soy un animal del tipo {type(self).__name__}")
class Perro(Animal):
    pass
class Gato(Animal):
    pass
Tayo = Perro("Pastor Aleman",2)
print(" Datos de Tayo ")
print(Tayo.especie)
print(Tayo.edad)
Tayo.decribeme()

Bola = Gato("Persa",1)
print(" Datos de Bola")
print(Bola.especie)
print(Bola.edad)
Bola.decribeme()