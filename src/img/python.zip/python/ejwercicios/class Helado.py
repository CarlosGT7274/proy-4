class Helado:
def __init__ (self, Descripcion, Precio):
    self.Descripcion = Descripcion
    self.Precio = Precio
# def nacos Helado(self):
# primt(rmiciado: * [self Descripcion)! rrecio: '5(selfPrecio)”)

# estaticnethod
# def verifica Pago(Eago) :

# Áf not isinstance(Zago, (imt, float):
# Print (Ingresa un Pago Valido...)
# exito)

# 4€ Pago < 0:
# print(' no cienes dinero!
# exito)

# def ger canbio(self, pago):
# return Pago - self.Precio

# dat vender (se1f, zago):
# self. Verifica Pago (Pago)
# 1£ Pago >- self precio:
# pEime( ES Sirviendo un Helado: (selfDeseripcion) *)
# 1 Pago — selfPrecio:
# pEinE(" Gracias por su compra... disfrure su Heladoco")
# ense:
# print(cons cambio: + (self.get Cambio (Pago) |”)
# exit" Gracias, transaccion completa. *)
# ese!
# prnt(er ralran:->5 (self.Precio - Pago), velva cuando tenga la cantidad completa")

# det menu (Lista nelados) :
# Le not leniLista Helados):
# print(- Ningun Helado definido Previamente ")
# L ese!
# prime (muestro Mens)
# For hezado in Lista Helados:
# helado. Datos_Belado ()