series = []

for i in range(5):
    serie = input(f"Ingresa la serie número {i+1}: ")
    series.append(serie)

series.sort()

print("Las series de televisión capturadas ordenadas son:")
for serie in series:
    print(serie)