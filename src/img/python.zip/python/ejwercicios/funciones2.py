from funciones import *

#Programa principal
def main():
    while True:
        opcion = menu()

        print(f"La opcción seleccionada fué: {opcion}")
        tarifa = 0
        print(f"seleccionaste: -> ${tarifa}")

        if opcion > 0 and opcion <= 9:
            if opcion == 9:
                print("Finalizando el programa")
                break

            medio = Medios[opcion -1]
            tarifa = Tarifas[opcion -1]
            Cobro(medio, tarifa)

            continuar = input("Preciona 0 para salir, o cualquier otra tecla para continuar")
            if continuar == '0':
                break
        else:
            print("Opcción inválida")
#-----Principal-----
main()