def fibonacci(n):
    if not isinstance(n, int):
        return "Error: argumento no es un número entero."
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)


def fibonacci_series(n):
    if not isinstance(n, int):
        return "Error: argumento no es un número entero."
    if n <= 0:
        return []
    else:
        series = []
        for i in range(n):
            series.append(fibonacci(i))
        return series

print(fibonacci_series(5))