import random

def juego_piedra_papel_tijera():
    puntos_usuario = 0
    puntos_pc = 0
    rondas = 3
    while rondas > 0:
        opciones = ["piedra", "papel", "tijera"]
        opcion_usuario = input("Escoge piedra, papel o tijera: ").lower()
        while opcion_usuario not in opciones:
            opcion_usuario = input("Opción no válida, por favor escoge piedra, papel o tijera: ").lower()
        opcion_computadora = random.choice(opciones)
        print("La computadora eligió: " + opcion_computadora)
        if opcion_usuario == opcion_computadora:
            print("Empate")
        elif (opcion_usuario == "piedra" and opcion_computadora == "tijera") or (opcion_usuario == "papel" and opcion_computadora == "piedra") or (opcion_usuario == "tijera" and opcion_computadora == "papel"):
            print("Ganaste esta ronda")
            puntos_usuario += 1
        else:
            print("Perdiste esta ronda")
            puntos_pc += 1
        rondas -= 1
    if puntos_usuario > puntos_pc:
        print("Ganaste el juego con un puntaje de " + str(puntos_usuario) + " a " + str(puntos_pc))
    elif puntos_usuario == puntos_pc:
        print("Empataron el juego con un puntaje de " + str(puntos_usuario) + " a " + str(puntos_pc))
    else:
        print("Perdiste el juego con un puntaje de " + str(puntos_usuario) + " a " + str(puntos_pc))
    jugar_de_nuevo = input("¿Quieres jugar de nuevo? (s/n)").lower()
    if jugar_de_nuevo == "s":
        juego_piedra_papel_tijera()
    else:
        print("Gracias por jugar")

juego_piedra_papel_tijera()