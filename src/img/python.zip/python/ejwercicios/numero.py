while True:
    num = int(input("Ingresa un número: "))
    if num == 0:
        print("El número es cero.")
    elif num > 0:
        print("El número es positivo.")
    else:
        print("El número es negativo.")
    continuar = input("¿Desea continuar? (s/n)")
    if continuar == "n":
        break