titulo = "tabla de múltiplos"
print(titulo.center(50,"*"))
numero = int(input("Ingresa el número: "))
print(f"Cargando la tabla del número{numero}")

print("--"*60)

for i in range(1, 21):
    print(f"{numero} x {i} = {numero*i}")