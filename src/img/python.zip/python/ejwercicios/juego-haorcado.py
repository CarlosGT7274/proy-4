import random, sys

ElAhorcado_Pics = [
    r"""
    +--+
    | |
    |
    |
    |
    |
    =====""",
    r"""
    +--+
    | |
    o |
    |
    |
    |
    =====""",
    r"""
    +--+
    | |
    o |
    | |
    |
    |
    =====""",
    r"""
    +--+
    | |
    o |
    /| |
    |
    |
    =====""",
    r"""
    +--+
    | |
    o |
    /|\ |
    |
    |
    =====""",
    r"""
    +--+
    | |
    o |
    /|\ |
    / |
    |
    =====""",
    r"""
    +--+
    | |
    o |
    /|\ |
    / \ |
    |
    ====="""]

# Incluimos la Primera Categoria
Categoria = 'Animales'
Palabras = '''HORMIGAS OSOS MURCIELAGOS CAMELLOS
CASTORES PERROS
 COYOTES CUERVOS GATOS PAVOS PATOS LOMBRICES
RINOCERONTES TORTUGAS
 ARAÑAS MARMOTAS RANAS'''.split()

# Sugerencia: podrian utilizar un diccionario para
# permitir al juego seleccionar una categoria diferente
def main():
    print('El ahorcado, versión de Al Sweirgart')
    Letras_Incorrectas = [] # Letras Incorrectas
    Letras_Correctas = [] # Letras Correctas
    Palabra_Secreta = random.choice(Palabras) # La palabra a Adivinar, es seleccionada de forma aleatoria.

    while True:
        DibujandoAhorcado(Letras_Incorrectas, Letras_Correctas, Palabra_Secreta)
        Mi_Letra = getPlayerGuess(Letras_Incorrectas + Letras_Correctas)

        if Mi_Letra in Palabra_Secreta:
            # Agregando la Letra Correcta en la lista de letras correctas.
            Letras_Correctas.append(Mi_Letra)

            # Revisando si el Jugador Ganó
            Palabra_Adivinada = True
            for Letras_Secretas in Palabra_Secreta:
                if Letras_Secretas not in Letras_Correctas:
                    Palabra_Adivinada = False
                    break

            if Palabra_Adivinada:
                print(f" Muy bien, la palabra adivinada es: {Palabra_Secreta}")
                print('Has ganado')
                break
            
        else:
            Letras_Incorrectas.append(Mi_Letra)
            if len(Letras_Incorrectas) == len(ElAhorcado_Pics) - 1:
                DibujandoAhorcado(Letras_Incorrectas, Letras_Correctas, Palabra_Secreta)
                print("Agotaste el límite de intentos!")
                print(f"La palabra fue: {Palabra_Secreta}")
                break

def DibujandoAhorcado(Letras_Incorrectas, Letras_Correctas, Palabra_Secreta):
    print(ElAhorcado_Pics[len(Letras_Incorrectas)])
    print(f'La categoría es: {Categoria}')
    print()
    print('Letras incorrectas: ', end='*')
    
    for Letras in Letras_Incorrectas:
        print(Letras, end=' ')
    if len(Letras_Incorrectas) == 0:
        print('No hay letras incorrectas aún!')
    print()

    # Muestra los espacios para la palabra secreta
    Espacios = ['_'] * len(Palabra_Secreta)

#    Reemplaza los espacios con las letras adivinadas correctamente
    for i in range(len(Palabra_Secreta)):
        if Palabra_Secreta[i] in Letras_Correctas:
            Espacios[i] = Palabra_Secreta[i]

    # Muestra la palabra secreta con espacios entre cada letra
    print(' '.join(Espacios))

def getPlayerGuess(ya_Adivinada):
    while True:
        print('Adivina una letra: ')
        Letra_Propuesta = input('->').upper()
        if len(Letra_Propuesta) != 1:
            print("Por favor, ingresa una sola letra")
        elif Letra_Propuesta in ya_Adivinada:
            print('Ya has adivinado esta letra, ingresa otra')
        elif not Letra_Propuesta.isalpha():
            print('Por favor, ingresa solo letras')
        else:
            return Letra_Propuesta
        
main()
            
            