numeros = []

for i in range(10):
    numero = int(input(f"Ingresa el número {i+1}: "))
    numeros.append(numero)

numeros.sort(reverse=True)
print("Los números ordenados de mayor a menor son:")
print(numeros)

numeros.sort()
print("Los números ordenados de menor a mayor son:")
print(numeros)