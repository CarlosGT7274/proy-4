class Animal:
    pass
class Perro(Animal):
    pass
#Derivando un objeto de la Clase perro.
kay = Perro()
#name: me permite conocer el nombre de la clase del objeto creado
print( f" Kay es un  {type(kay).__name__}")
#bases: me permite conocer la clase padre del objeto creado.
print(f" que a su vez, un perro es un: {Perro.__bases__}")