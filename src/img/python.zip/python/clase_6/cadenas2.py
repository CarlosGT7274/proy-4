Cadenas = "         Bienvenidos a la prog. en Python         "

print(" Tratamiento de Cadenas parte 2 ")
print("Strip:  Quita los espacios en una cadena:", Cadenas.strip())
print("lStrip: Quita los espacios de la IZquierda:", Cadenas.lstrip())
print("rStrip: Quita los espacios de la IZquierda:", Cadenas.rstrip())
Cadenas = Cadenas.strip()
print(" Alineacion del Texto ")
print(" Central:.-> ", Cadenas.center(80))
#Caracter de alineacion
print(" Central:.-> ", Cadenas.center(80, "*"))
print(" Derecha:.-> ", Cadenas.rjust(80))
print(" Derecha:.-> ", Cadenas.rjust(80,"-"))
print(" Izquierda:.-> ", Cadenas.ljust(80))
print(" Izquierda:.-> ", Cadenas.ljust(80,"+"))

print("\n Busqueda en Cadenas ")
#print("Index:-> ", Cadenas.index("Java"))
print("Find:-> ", Cadenas.find("a")) # -> Si no encuentra la subcadena retornará -1 
#Si la localiza retornará la posición.

print("rFind:-> ", Cadenas.rfind("a"))
'''
#Ejemplo 
   Hola Mundo
   Izquierda a derecha
   -> 2
   Derecha a Izquierda
   -> 10
'''


print(" Tratamiento logico ")
Cadena = "Hola" #Alfabetica 
Cadena1 = "12345" #Numerica
Cadena2 = "Hola123" #AlfaNumerica

print(" Esta compuesta de Solo Letras:-> ", Cadena.isalpha())#True 
print(" Esta compuesta de Solo Letras:-> ", Cadena1.isalpha()) #False
print(" Esta compuesta de Solo Letras:-> ", Cadena2.isalpha()) #False
print("*"*25)
print(" Esta compuesta de Solo Numeros:-> ",Cadena, Cadena.isnumeric())#false
print(" Esta compuesta de Solo Numeros:-> ",Cadena1, Cadena1.isnumeric()) #True
print("-"*25)
Cadena = "*"
print(" Esta compuesta de Numeros y letras:-> ",Cadena , " --- ",  Cadena.isalnum())#True
print(" Esta compuesta de Numeros y Letras:-> ",Cadena1," --- ", Cadena1.isalnum()) #True
print(" Esta compuesta de Numeros y Letras:-> ",Cadena2," --- ", Cadena2.isalnum()) #True