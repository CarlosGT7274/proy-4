print('Tratamiento de Cadenas')
Cadena1 = "bienvenidos a la programación con python"
Cadena2 = "BIENVENIDOS A LA PROGRAMACION CON PYTHON"

print("Capitalize: -> ", Cadena1.capitalize())
print("Title:-> ", Cadena2.title())
print("Index:-> a se encuentra en la pos.:-> ", Cadena1.index('a'))
print("Upper:-> Mayusculas ", Cadena1.upper())
print("Lower:-> Minusculas ", Cadena2.lower())
print("SwapCase:-> Alternando Mayusculas y minusculas", Cadena1.swapcase())
print("Count:-> Numero de Caracteres repetidos: ", Cadena2.count('I'))
print("Replace: -> Remplaza un caracteres por otro en la cadena ", Cadena1.replace("o",'V'))