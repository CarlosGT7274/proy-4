print(" Trabajando sin Format ")
Nombre = "Juan Martinez"
Edad = 32
print(" Nombre: -> ", Nombre ,"\n Edad:->", Edad )

print(" Trabajando con Format ")
print(" Nombre:-> {} \n Edad:-> {} ".format(Nombre,Edad))
print(" Nombre:-> {0} \n Edad:-> {1} ".format(Nombre,Edad))
print("*"*23)
print(" En format el orden importa ")
print(" Nombre:-> {1} \n Edad:-> {0} ".format(Nombre,Edad))
print(" En format podemos reutilizar los valores tantas veces necesites. ")
print(" Nombre:-> {1}---{1}* {0} \n Edad:-> {0}xxx{1} ".format(Nombre,Edad))
print(" Nombre:-> {0} \n Edad:-> {1} \n Salario: -> ${2}".format(Nombre,Edad, 150 * 20 ))