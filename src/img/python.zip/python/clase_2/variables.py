nombre = "juan Martinez"
Edad = 32
Direccion = "av. Siempre viva"
correo = "juanmartinez@gmail.com"
pasatiempo = '''Mis pasatiempos son:
tocar el violin
pintar
salir a correr
'''

salarioActual = 2330.80

print("-------------------------------------")
print("Visualizando los Datos")
print("Nombre " + nombre)#"" con textos
print("Edad", Edad)#, con texto y numero
print('''correo''', correo)
print(pasatiempo)
#-----------------------------------------------
print(type(nombre))
print(type(Edad))
print(type(salarioActual))
#--------------------------------------------------
print("un poco sobre los objetos")
print(nombre.upper())#mayusculas
print(nombre.lower())#minusculas
print(dir(salarioActual))
print(salarioActual.__round__(0))