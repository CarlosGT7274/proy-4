'repaso.py'
# ', " o ''' dentro de python representan TEXTO|CADENA|STRING
print('hola mundo')
print("Esto es un texto")
print('''Esto tambien nos permite imprimir un texto''')