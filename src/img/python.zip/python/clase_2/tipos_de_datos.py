print("tipos de datos");
print("Esto es una cadena");
print('Aqui un numero:""', 23)#'apostrofe
print("Aqui un numero:''", 23)#"comillas"