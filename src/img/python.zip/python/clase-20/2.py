import matplotlib.pyplot as plt
import numpy as np # Importamos numpy como el alias np
a = np.linspace(0, 20, 100) # Posición de inicio de gráfica 0, Amplitud eje
b = np.sin(a) #Se establece la función que se desea trazar
c = plt.plot(a, b, 'c-3', linewidth=2) # Se crea un diseño de dibujo con
c = plt.plot(a + 0.2, b - 1, 'r-o', linewidth=2) # Se crea un diseño de

plt.xlabel("Mensaje en eje X", fontsize=10,color='red')
plt.ylabel("Mensaje en eje Y", fontsize=10, color='blue')
plt.text(5, 0, "Texto en gráfico", fontsize=12)
plt.title("Titulo de la Gráfica", fontsize=20)
plt.legend(('Etiqueta1', 'Etiqueta2', 'Etiqueta3'), loc='upper left')
plt.grid(True)
plt.savefig('figura3.png', dpi=300) # guarda la gráfica con 300dpi
plt.show()
