import matplotlib.pyplot as plt
import numpy as np # Importamos numpy como el alias np
a = np.linspace(0, 10, 50)
b = np.sin(a)
plt.plot(a, b, 'y--', linewidth=2)
plt.show()
