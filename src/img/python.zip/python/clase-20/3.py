import matplotlib.pyplot as plt
import numpy as np # Importamos numpy como el alias np
a = np.linspace(0, 20, 50)
b = np.sin(a)
plt.figure()
# plot 1
plt.subplot(2, 2, 1)
plt.plot(a, b, 'r-3')
# Segunda grafica
plt.subplot(2, 2, 2)
plt.plot(a + 2, b * 25, 'g-o')
# Tercera grafica
plt.subplot(2, 2, 3)
plt.plot(b, a, 'b-1') #Se invierte las coordenadas y por X
# Cuarta grafica
plt.subplot(2, 2, 4)
plt.plot(a, b, 'k-2')
# Mostramos en pantalla
plt.show()
