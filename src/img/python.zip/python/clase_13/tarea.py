medios = '''Persona,Bisicleta,Motocicleta,Automovil,Camioneta,Autobus,Trailer,Torton'''.split(",")
tarifas = '''5,10,20,40,50,120,220,258'''.split(",")


def menu():
    conatdor = 1
    print(" nuestro menu ")
    print(" ------------ ")

    for medio in medios:
        print(f"{conatdor}.-{medio}.-${tarifas[conatdor-1]}")
        conatdor += 1
    print("9.- Salir")
    print("\n-----------------------------")
    opcion = int(input("ingrese la opcion: "))
    
menu()