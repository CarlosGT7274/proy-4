'Excepciones2.py'

try:
    a = 10
    b = 0
    print(f"{a} / {b} = {a/b}")

except (ZeroDivisionError, TypeError):
    print(" Intenta dividir entre cero o uno de los valores es un texto ")
