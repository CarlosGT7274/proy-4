try:
    a = 10
    b = "Hola"
    print(f"{a} / {b} = {a/b}")
except Exception as e:
    print(f" Ocurrio la siguiente excepcion: -> {e}")
else:
    print("Else: -> Este bloque se ejecuta si no hay Excepciones")
finally:
    print("Finally: ->  Este bloque se ejecuta SIEMPRE haya o no excepciones ")
