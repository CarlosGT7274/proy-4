try:
    a = 10
    b = "hola"
    print(f"{a} / {b} = {a/b}")

except Exception as e:
    print(f" Ocurrio la siguiente excepcion: -> {e}")
