estados = ["puebla", "oaxaca","veracruz"]

valor = input("ingresa un elemento: ")
posicion = int(input("¿en que posicion se agregara?: "))

try:
    estados.insert(posicion, valor)
    print(f" EStados: {estados}")
except exception as e:
    print(f"tenemos un error :) {e}")

