try:
    a = 10
    b = 5
    print(f"{a} / {b} = {a/b}")
except Exception as e:
    print(f" Ocurrio la siguiente excepcion: -> {e}")
else:
    print("Este bloque se ejecuta si no hay Excepciones")
