MiArchivo = open("Ejemplo.txt",'w')
print(" Se ha creado el archivo correctamente ")

#open("Ejemplo.txt",'w')

'''
1.- El primer argumento-> Nombre del archivo
      formas de agregar la ruta, relativa o absoluta.
      Ejemplos: 
      
      Ruta relativa: -> Solo agregamos el nombre
      open("Ejemplo.txt",'w')
      
      Ruta Absoluta:
      open( r"C:\Users\MiPc\Desktop\PythonProyects\Ficheros\MiArchivo.txt" ,'w')
      open( "C:\\ Users\\MiPc\\Desktop\\PythonProyects\\Ficheros\\MiArchivo.txt" ,'w')
      
2do.- 
    open( r"C:\Users\MiPc\Desktop\PythonProyects\Ficheros\MiArchivo.txt")
    por defecto python agrega 'r' al final.
    
    descripcion: 
    r -> Abre el fichero en modo lectura
    w -> Modo Escritura
    a -> Modo Escritura al final de la informacion existente
    w+ -> Lectura y escritura.
    r+ -> Modo lectura y escritura.
    a+ -> Lectura y escritura añadido.      
'''
try:
    MiArchivo = open("Ejemplo.txt", 'w')
    Cadena = "Bienvenido al manejo de ficheros en python"

    MiArchivo.write(Cadena)
    print(" Se ha guardado el texto correctamente ")

except Exception as e:
    print(f" Ha ocurrido algun error: -> {e}")
'''
try:
    MiArchivo = open("Ejemplo.txt", 'a')
    Cadena = "\n Utilizando la a, el texto nuevo se agrega al final "
    MiArchivo.write(Cadena)
    print(" Se ha guardado el texto correctamente ")

except Exception as e:
    print(f" Ha ocurrido algun error: -> {e}")'''
