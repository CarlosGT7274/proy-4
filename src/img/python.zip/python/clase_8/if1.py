print("trabajando con if")
color = input("igresa tu color favorito: ")

if color == 'Azul':
    print("oh me gusta el azul")
elif color == 'Rojo':
    print("wow rojo, tambien me agrada")