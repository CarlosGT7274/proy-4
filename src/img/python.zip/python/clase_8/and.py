print("Trabajando con operadores logicos")
print("operador and")

numero = int(input("ingresa un numero: "))

if numero >=5 and numero <=10:
    print("el numero esta dentro del rango")
else:
    print("el nunmero es invalido")

print("operador or")
print("uno o otro")

numeros = int(input("ingresa un numero: "))

if numeros >=10 or numeros <=20:
    print("el numero esta dentro del rango '{}' {}".format(numeros, "es valido"))
else:
    print("el nunmero es invalido '{numero}'\n no es valido")