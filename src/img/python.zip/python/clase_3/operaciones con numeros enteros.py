num1 = 6
num2 = 3
num3 = 2
num4 = 9

print("*** TRABAJANDO CON ENTEROS: ***")
print('-------------------------------')
print("suma: ", num1 + num3)

print("resta: ", num4 - num3)

