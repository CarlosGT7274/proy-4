residencia = "Lomas de Angelopolis"
precio = 12_980_234
enganche = 0.2
pago1 = precio * enganche
restoapagar = precio - pago1
print("** Detalle de venta de bienes raices Vida_lujos**")
print('recidencia',residencia)
print('Su primer pago sera: $',pago1.__round__())
print('restado: $', restoapagar)