print(" En python todos los datos son objetos ")

Cadena = str(" Esto es una cadena de texto ")
Texto = "hola Mundo"
print("Cadena: -> ", Cadena)
print("Cadena: -> ", Texto)

Numero = int("23")
Numero3 = int(10.899)
Numero2 = 209.892
print("Numero: -> ", Numero)
print("Numero: -> ", int(Numero2) )
print("Numero: -> ", int(Numero3) )

Flotante = float(10)
Flotante2 = 5
print("Flotante: ->", Flotante)
print("Flotante: ->", float(Flotante2))

NumeroComplejo = complex("2+4j")
NumeroComplejo2 = 4+10j
print("Numero Complejo", NumeroComplejo)
print("Numero Complejo", NumeroComplejo2)

