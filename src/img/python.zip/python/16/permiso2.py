class cuenta:
    def __init__(self, nombre, clave):
        self.__nombre = nombre
        self.__clave = clave
    
    def mostrandodatos(self):
        return f" Nombre: {self.__nombre} \n clave: {self.__clave}"
    
    def getnombre(self):
        return self.__nombre
    


cuenta1 = cuenta("juan", "juan123")

print("mostrando ambos valores a traves de un metodo publico")


print(" datos ")
print(cuenta1.mostrandodatos())
print("solo el nombre: ", cuenta1.getnombre())
    