for numero in range(1001):
    print(numero)

#crear una serie desde 500 hasta 1000
# range( inicio, final ):
for numero in range(500, 1001):
    print(numero)

#Crear una serie desde 20 hasta 1000 de 100 en 100
#range(inicio, final):
for numero in range(20,1000,100):
    print(numero)

#Crear una serie desde 1 hasta 10 de 0.5 en 0.5
#range(inicio, final):
#nota: range solo hara ciclos con numeros enteros
#for numero in range(20,1000,100):
#    print(numero)

#crear una serie desde 1 hasta 10 de 0.5 en 0.5
# range(inicio, final):
#nota: range solo hara series de enteros
for numero in range(100, 1 , -2):
    print(numero)

#crear una serie desde 1 hasta 10 de 0.5 en 0.5
# range(inicio, final ):
#nota: range solo hara series de enteros.
contador = 1
while (contador <= 10):
    print(contador)
    contador += 0.5