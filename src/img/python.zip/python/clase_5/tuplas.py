print("trabajando con tuplas")

estados = ("puebla", "oaxaca", 'veracruz', 'hidalgo')
print("mostrado todos los elementos: ", estados)
print("Mostrando un elemento en concreto: ", estados[3])

'no se pueden ordenar los elementos de una tupla'
#print("Ordenando una tupla: ", estados.sort())

print('convirtiendo una tupla a una lista')
estados = list(estados)#Realizando la convercion de una tupla a una lista.
print('tipo de Estados: ', type(estados))

estados.sort()
elementos = len(estados)
print(f"Estados: {estados} Tiene: {elementos} elementos")
print("regresando la lista tupla ")
estados = tuple(estados)
#verificando el tipo
print(type(estados))
