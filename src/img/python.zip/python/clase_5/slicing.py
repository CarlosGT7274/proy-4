lenguajes = ["java", "c++", "python", 'c', 'php']

print("trabajando con slicing en python")
print("-"*30)
print("mostrando todos los elementos: ", lenguajes)
#lenguajes[:] → inicio : final
print("mostrando todos los elementos: ", lenguajes[:])
#el final dera el limite -1.
print("mostrando desde 1:5 :", lenguajes[1:5] ,1,2,3,4)
#tiene un inicio, pero no un final
print("mostrando desde 1: final : ", lenguajes[1:])
#tiene un inicio, pero no un final, he incremento
print("Mostrando desde inicio: hasta el final: incremento. : ", lenguajes[0:len(lenguajes):2])

#una subsecuencia tiene la siguiente estrutura
#nombre [ [inicio] : [final] : [incremento] ]