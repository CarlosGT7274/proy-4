def saludo():
    print("hola bienvenido a la programacion recursiva en python")
    saludo()
    
def main():
    saludo()


if __name__ == '__main__':
    main()
