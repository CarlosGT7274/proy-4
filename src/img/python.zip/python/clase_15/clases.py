class coche():
    marca = "nissan"
    
    def __init__(self, modelo, color, precio):
        self.modelo = modelo
        self.color = color
        self.precio = precio
        
    def descripcion(self):
        return f"modelo {self.modelo}, \n color: {self.color} \n precio: ${self.precio}"
        
    @classmethod
    def getmarca(cls):
        return f"la marca del coche es: {cls.marca}"
        
    @staticmethod
    def aceleracion():
        return "todos los coches aceleran"
        
ferrari = coche("ferrari", "rojo", 1_980_999)
print(" intentando imprimir los valores de nuestro objeto ")
print( ferrari.descripcion() )