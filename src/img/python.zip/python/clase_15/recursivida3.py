def serie_ascendente(n):
    print(f" numero:  {n}")
    n +=1
    
    if n <= 100:
        serie_ascendente(n)

def main():
    serie_ascendente(1)
    
if __name__ == '__main__':
    main()