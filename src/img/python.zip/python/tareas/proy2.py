import requests
import tkinter as tk

# Función para realizar la conversión
def convert_currency():
    # Obtener las monedas seleccionadas y la cantidad
    base_currency = base_currency_var.get()
    target_currency = target_currency_var.get()
    amount = float(amount_entry.get().replace(',', '.'))

    # Realizar la solicitud a la API
    url = f"https://v6.exchangerate-api.com/v6/85c8ca8634c0ac1bf2a43f71/latest/{base_currency}"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        base_code = data['base_code']
        rates = data['conversion_rates']

        if target_currency in rates:
            rate = rates[target_currency]
            converted_amount = amount * rate
            result_label.config(text=f"{amount} {base_code} es equivalente a {converted_amount:.2f} {target_currency}")
        else:
            result_label.config(text=f"No se encontró la tasa de cambio para la moneda {target_currency}")
    else:
        result_label.config(text="Error al realizar la solicitud a la API")

# Crear la ventana de la aplicación
root = tk.Tk()
root.title("Conversor de monedas")

# Crear los widgets
base_currency_var = tk.StringVar(value="USD")
target_currency_var = tk.StringVar(value="EUR")

base_currency_label = tk.Label(root, text="Moneda base:")
base_currency_menu = tk.OptionMenu(root, base_currency_var, "USD", "EUR", "GBP", "JPY", "MXN")
target_currency_label = tk.Label(root, text="Moneda de destino:")
target_currency_menu = tk.OptionMenu(root, target_currency_var, "USD", "EUR", "GBP", "JPY", "MXN")
amount_label = tk.Label(root, text="Cantidad:")
amount_entry = tk.Entry(root)
convert_button = tk.Button(root, text="Convertir", command=convert_currency)
result_label = tk.Label(root, text="")
button_quit = tk.Button(root, text="Salir", command=root.quit)

# Organizar los widgets en la ventana
amount_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
amount_entry.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
base_currency_label.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
base_currency_menu.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
target_currency_label.grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
target_currency_menu.grid(row=1, column=2, padx=5, pady=5, sticky=tk.W)
convert_button.grid(row=1, column=3, columnspan=2, padx=5, pady=5)
result_label.grid(row=2, column=0, columnspan=2, padx=5, pady=5)
button_quit.grid(column=3, row=2, padx=5, pady=5, sticky=tk.E)

# Ejecutar la aplicación
root.mainloop()

