base = int(input("Ingrese la base: "))
exponente = int(input("Ingrese el exponente: "))
resultado = base ** exponente
print(f"{base}^{exponente} = {resultado}")
