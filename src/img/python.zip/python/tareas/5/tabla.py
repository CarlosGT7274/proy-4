frutas = {
    "Puebla": {"Enero": 100, "Febrero": 120, "Marzo": 90, "Total": 310},
    "Morelos": {"Enero": 90, "Febrero": 80, "Marzo": 50, "Total": 220},
    "Veracruz": {"Enero": 150, "Febrero": 40, "Marzo": 200, "Total": 390},
    "Jalisco": {"Enero": 130, "Febrero": 90, "Marzo": 80, "Total": 300}
}

print("Estado  Enero  Febrero  Marzo  Total")
for estado, ventas in frutas.items():
    print("{:8} {:7} {:8} {:6} {:5}".format(estado, ventas["Enero"], ventas["Febrero"], ventas["Marzo"], ventas["Total"]))