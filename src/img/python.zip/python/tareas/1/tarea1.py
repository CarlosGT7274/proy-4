num = int(input("Ingrese un número: "))
resultado = num ** 2
print("El cuadrado de", num, "es", resultado)