import requests

base_currency = "USD" # Moneda base (se puede cambiar por otra)
target_currency = "EUR" # Moneda de destino (se puede cambiar por otra)
amount = 100 # Cantidad en la moneda base

url = f"https://v6.exchangerate-api.com/v6/85c8ca8634c0ac1bf2a43f71/latest/{base_currency}"
response = requests.get(url)

if response.status_code == 200:
    data = response.json()
    base_code = data['base_code']
    rates = data['conversion_rates']

    if target_currency in rates:
        rate = rates[target_currency]
        converted_amount = amount * rate
        print(f"{amount} {base_code} es equivalente a {converted_amount:.2f} {target_currency}")
    else:
        print(f"No se encontró la tasa de cambio para la moneda {target_currency}")
else:
    print("Error al realizar la solicitud a la API")
