frutas = []

for i in range(10):
    fruta = input("Ingrese el nombre de una fruta: ")
    frutas.append(fruta)

frutas.sort()
print("Lista de frutas ordenadas: ", frutas)