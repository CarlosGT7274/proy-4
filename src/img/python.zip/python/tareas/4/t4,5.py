def convertir_a_dolares(cantidad_pesos):
    t = 0.053
    cantidad_dolares = cantidad_pesos * t
    return cantidad_dolares

cantidad_pesos = float(input("Ingrese la cantidad de pesos a convertir: "))
cantidad_dolares = convertir_a_dolares(cantidad_pesos)
print(f"{cantidad_pesos} pesos son {cantidad_dolares} dólares.")