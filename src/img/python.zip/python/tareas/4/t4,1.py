

def volumen_esfera(r):
    v = (4/3) * 3.1416 * (r ** 3)
    return v

radio = float(input("Ingrese el radio de la esfera: "))
vol = volumen_esfera(radio)
print("El volumen de la esfera es: ", vol)