for num in range(2000, 3001):
    if num % 2 == 0:
        print(num)

#numerospares