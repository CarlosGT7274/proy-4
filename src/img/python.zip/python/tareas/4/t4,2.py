def fahrenheit_a_celsius(f):
    c = (f - 32) * 5/9
    return c

f = float(input("Ingrese la temperatura en grados Fahrenheit: "))
celsius = fahrenheit_a_celsius(f)
print(f"{f} grados Fahrenheit son {celsius} grados Celsius.")