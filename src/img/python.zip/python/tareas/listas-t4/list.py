## Agregar los elementos al final de la lista.
#a = [1, 2, 3, 4]
#a.extend([5, 6, 7, 8, 9])
#print( a )
## Remover un ítem indicando su posición y obtener el valor eliminado.
#a = ["CPython", "PyPy", "Stackless"]
#eliminado = a.pop(1)
#print( eliminado )
## Obtener la posición de un elemento indicando su valor.
#a = ["CPython", "PyPy", "Stackless", "PyPy"]
#a.index("Stackless")
#a.index("CPython")
#a.index("PyPy") # Retorna la posición del primer elemento encontrado.
#a.index("IronPython") #De no ser encontrado, lanzará una excepción.
## Determinar cuántas veces aparece un ítem en la lista.
a = ["Perro", "Gato", "Perro", "Caballo", "Perro", "Gato"]
a.count("Perro")
a.count("Caballo")
a.count("Gato")
# Ordernar los elementos de menor a mayor.
a = [4, 7, 5, 6, 2, 1, 3]
a.sort()
print ( a )
# En las cadenas, su valor numérico será determinado
# por el código del primer caracter.
a = ["Hola", "Recursos", "Python"]
a.sort()
# Invertir el orden de todos los elementos.
#a = [1, 2, 3, 4, 5]
#a.reverse()
## Puede ser utilizado junto a sort() para ordenar de mayor a menor.
#a = [4, 7, 5, 6, 2, 1, 3]
#a.sort()
#a.reverse()
#print(a)