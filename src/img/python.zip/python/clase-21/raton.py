' Eventos, coordenadas del ratón '#
from tkinter import Tk, Canvas
ventana = Tk()
ventana.geometry("500x500")
ventana.title(" Canvas ")
ventana.resizable(False,False)
lienzo = Canvas(ventana, #objeto al que se unirá
                width=500, #ancho
                height=300, #alto
                bg="yellow") #Color de fondo

def Posicion_raton(evento):
    posX = evento.x #posicion en X
    posY = evento.y #posicion en Y
    print(" ----------------- ")
    print(" coordenadas del Puntero ")
    print(f" X = {posX}, Y {posY}")


ventana.bind("<Button-1>", Posicion_raton) #Clic izq
lienzo.pack()
ventana.mainloop()
