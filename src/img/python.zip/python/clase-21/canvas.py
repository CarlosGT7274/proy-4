'Creando un lienzo de trabajo!'#canvas
from tkinter import Tk, Canvas, PhotoImage
ventana = Tk()
ventana.geometry("500x500")
ventana.title(" Canvas ")
ventana.resizable(False,False)
lienzo = Canvas(ventana, #objeto al que se unirá
                width=500, #ancho
                height=500, #alto
                bg="white") #Color de fondo
lienzo.create_text(200,200,
                   text="Acerca tu puntero al texto",
                   font=("Curier",15), #fuente del texto
                   fill="blue", #Color inicial.
                   activefill="pink" #Color al momento de pasar el puntero sobre el texto.
                    )

lienzo.create_text(200,250,
                   text="Acerca tu puntero al texto",
                   font=("Curier",20),
                   fill="pink",
                   activefill="gold"
                    )
lienzo.pack()
ventana.mainloop()
