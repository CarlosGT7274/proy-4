import tkinter as tk

root = tk.Tk()
root.geometry("300x200")

# Lista de opciones para el menú desplegable
options = ["Opción 1", "Opción 2", "Opción 3", "Opción 4"]
# Variable que almacenará la opción seleccionada del menú desplegable
selected_option = tk.StringVar()
# Función para obtener la opción seleccionada
def get_selected_option():
    print("La opción seleccionada es:", selected_option.get())

# Crear el menú desplegable
dropdown = tk.OptionMenu(root,
                         selected_option,
                         *options)
dropdown.pack(pady=10)

# Botón para obtener la opción seleccionada
button = tk.Button(root,
                   text="Obtener opción seleccionada",
                   command=get_selected_option)
button.pack()

root.mainloop()
