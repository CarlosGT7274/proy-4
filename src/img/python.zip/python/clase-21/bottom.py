'Botones'#ejemplo de botones
from tkinter import Tk, Canvas, Button, messagebox
ventana = Tk()
ventana.geometry("500x500")
ventana.title(" Canvas ")
ventana.resizable(False,False)
lienzo = Canvas(ventana, #objeto al que se unirá
                width=500, #ancho
                height=300, #alto
                bg="yellow") #Color de fondo

def Mostrar_Mensaje():
    resultado = messagebox.showinfo("Mensaje"," Esto es un message box en python ")
    print(" Resultados de los botones ")
    print(resultado)
    resultado = messagebox.showerror("Mensaje de Error", "A ocurrido un Error!")
    print(resultado)
    resultado = messagebox.askyesno("Mensaje de Pregunta"," ¿Desea continuar? ")
    print(resultado)
    resultado = messagebox.askokcancel("Mensaje si, cancelar","¿Desea seguir?")
    print(resultado)


boton_Mostrar = Button(text="Mostrar",
                       padx=10,
                       fg="white",
                       bg="Gold",
                       command=Mostrar_Mensaje)
boton_Mostrar.pack()
lienzo.pack()

ventana.mainloop()
