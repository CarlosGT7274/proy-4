import numpy as np
import matplotlib.pyplot as plt

def h(x):
    return np.sin(x)
'Introducimos los valores para dibujar el eje en x:0-10 ; y ele eje y:-1 a 1'
v=[0,10,-1,1]
'establecemos 100 puntos en el intervalo, de 0 a 10 para ser graficados'
x=np.linspace(0,10,100)

plt.plot(x,h(x),'y-',label='seno')

plt.xlabel('posición en X')
plt.title('Función seno')

plt.legend(loc=1)
plt.axis(v)
plt.grid()
plt.show()
