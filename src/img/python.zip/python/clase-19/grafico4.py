import matplotlib.pyplot as plt

X = list( range(10) )
#Listas por comprension
'Una lista por comprension tiene'
'la siguiente estructura: '
'    la acción a repetir  {x ** 0.5}   for x in X    ----> 0 ^0.5, 1 ^0.5, 2^0.5, 3^0.5... 9^0.5'
'''
Y1 = list()
for x in X:
Y1.append(x ** 0.5) 
'''


Y1 = [ x ** 0.5 for x in X]
Y2 = [ x for x in X]
Y3 = [ x ** 1.5 for x in X]
Y4 = [ x ** 2.0 for x in X]

plt.suptitle("Ejemplo de dos funciones simultaneas", fontsize =24 )

plt.subplot2grid( (2,2), (0,0), colspan=2)
plt.title(" Cuatro funciones representadas simultaneamente", fontsize = 10)
plt.plot(X,Y1)
plt.plot(X,Y2)
plt.plot(X,Y3)
plt.plot(X,Y4)

plt.subplot2grid( (2,2), (1,0), colspan=2)
plt.title(" Dos funciones representadas simultaneamente", fontsize = 10)
plt.plot(X,Y1)
plt.plot(X,Y2)
plt.show()


plt.show()
