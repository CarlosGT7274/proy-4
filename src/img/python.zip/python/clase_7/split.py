#Utilice Split para crear una lista, a partir de una Cadena.
Palabras = "Oso Lobo Ratón Cocodrilo Perro Gato".split()
print("Mostrando las palabras: -> ", Palabras) #Con el espacio con caracter por defecto
Palabras = "Oso+Lobo+Ratón+Cocodrilo+Perro+Gato".split("+")
print("Mostrando las palabras: -> ", Palabras) #Agregando la coma como caracter se separación.

estados = ['puebla', 'jalisco', 'hidalgo']
cadenaestados = "|".join(estados)
print("cadena de estados: ",cadenaestados)