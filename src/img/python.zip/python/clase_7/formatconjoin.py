print("Tabla de calificacion del curso de python septiembre - Diciemre 2021")


listasalum = [
    ['denisse', 'gonzalez', 5, 7, 9, 9.2],
    ['Maday', 'santiago', 5, 7, 9, 9.2],
    ['Jesus', 'Gonzalez', 5, 7, 9, 9.2],
    ['raul', 'Rodriguez', 5, 7, 9, 9.2],
    ['pedro', 'alcantara', 5, 7, 9, 9.2],
    ['Dolores', 'morales', 5, 7, 9, 9.2],
    ['iness', 'flores', 7, 6, 5, 8]   
]
print(listasalum)
tabla = """\
+--------------------------------------------------------------------------------+
| Nombre    Apellido        Prmero Segundo Tercero          Promedio anual       |
|--------------------------------------------------------------------------------|
{}                                                                               
+--------------------------------------------------------------------------------+\
"""

tabla = (tabla.format('\n'.join("| {:<8} {:<12} {:>8} {:>6} {:>7} {:>22}           |".format(*fila)
    for fila in listasalum)))
print (tabla)
 