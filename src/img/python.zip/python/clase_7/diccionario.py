diccionario = {"uva": 80, "pera":45, "limon":60, "sandia":100 }

print("mostrar el precio por kilo de la uva: $", diccionario["uva"])
diccionario["uva"] = 60
print("mostrar el precio por kilo de la uva: $", diccionario["uva"])