import random

print("generando numeros aleatorio en un rango")
numero = random.randint(5,10)#5,6,7,8,9,10
print(f"el numero generado fue: {numero}")
numero = random.randint(5,10)#5,6,7,8,9,10
print(f"el numero generado fue: {numero}")



